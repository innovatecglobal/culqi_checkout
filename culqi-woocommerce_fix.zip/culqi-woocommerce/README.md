# Culqi WooCommerce Plugin v2.1.1

<table>
  <tr>
    <td>Wordpress</td>
    <td>v4.7</td>
  </tr>
  <tr>
    <td>WooCommerce</td>
    <td>v2.6.11</td>
  </tr>
</table>
